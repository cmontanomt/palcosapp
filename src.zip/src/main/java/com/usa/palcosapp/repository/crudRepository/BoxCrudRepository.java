package com.usa.palcosapp.repository.crudRepository;

import com.usa.palcosapp.model.BoxModel;
import org.springframework.data.repository.CrudRepository;

public interface BoxCrudRepository extends CrudRepository<BoxModel,Integer> {
}
